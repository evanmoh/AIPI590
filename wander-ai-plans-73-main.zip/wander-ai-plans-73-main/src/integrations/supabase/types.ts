export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      places: {
        Row: {
          avg_cost_usd: number
          category: string
          city: string
          created_at: string | null
          duration_hours: number
          evening_fit: boolean
          id: string
          image_url: string | null
          key_tip: string | null
          lunch_fit: boolean
          morning_fit: boolean
          name: string
          overall_rating: number | null
          place_id: string
          url: string | null
        }
        Insert: {
          avg_cost_usd?: number
          category: string
          city: string
          created_at?: string | null
          duration_hours: number
          evening_fit?: boolean
          id?: string
          image_url?: string | null
          key_tip?: string | null
          lunch_fit?: boolean
          morning_fit?: boolean
          name: string
          overall_rating?: number | null
          place_id: string
          url?: string | null
        }
        Update: {
          avg_cost_usd?: number
          category?: string
          city?: string
          created_at?: string | null
          duration_hours?: number
          evening_fit?: boolean
          id?: string
          image_url?: string | null
          key_tip?: string | null
          lunch_fit?: boolean
          morning_fit?: boolean
          name?: string
          overall_rating?: number | null
          place_id?: string
          url?: string | null
        }
        Relationships: []
      }
      plan_places: {
        Row: {
          created_at: string | null
          day_number: number
          id: string
          order_in_day: number
          place_category: string
          place_cost: number
          place_name: string
          plan_id: string
          time_slot: string
        }
        Insert: {
          created_at?: string | null
          day_number: number
          id?: string
          order_in_day: number
          place_category?: string
          place_cost?: number
          place_name?: string
          plan_id: string
          time_slot?: string
        }
        Update: {
          created_at?: string | null
          day_number?: number
          id?: string
          order_in_day?: number
          place_category?: string
          place_cost?: number
          place_name?: string
          plan_id?: string
          time_slot?: string
        }
        Relationships: [
          {
            foreignKeyName: "plan_places_plan_id_fkey"
            columns: ["plan_id"]
            isOneToOne: false
            referencedRelation: "saved_plans"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          address: string | null
          avatar_url: string | null
          bio: string | null
          created_at: string | null
          email: string | null
          full_name: string | null
          id: string
          updated_at: string | null
        }
        Insert: {
          address?: string | null
          avatar_url?: string | null
          bio?: string | null
          created_at?: string | null
          email?: string | null
          full_name?: string | null
          id: string
          updated_at?: string | null
        }
        Update: {
          address?: string | null
          avatar_url?: string | null
          bio?: string | null
          created_at?: string | null
          email?: string | null
          full_name?: string | null
          id?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      ratings: {
        Row: {
          companion: string | null
          created_at: string | null
          id: string
          place_id: string
          rating: number
          review_text: string | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          companion?: string | null
          created_at?: string | null
          id?: string
          place_id: string
          rating: number
          review_text?: string | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          companion?: string | null
          created_at?: string | null
          id?: string
          place_id?: string
          rating?: number
          review_text?: string | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "ratings_place_id_fkey"
            columns: ["place_id"]
            isOneToOne: false
            referencedRelation: "places"
            referencedColumns: ["id"]
          },
        ]
      }
      saved_plans: {
        Row: {
          city: string
          companion: string
          created_at: string | null
          duration_days: number
          id: string
          plan_name: string
          start_date: string | null
          updated_at: string | null
          user_id: string
          vibe: string
        }
        Insert: {
          city: string
          companion: string
          created_at?: string | null
          duration_days: number
          id?: string
          plan_name: string
          start_date?: string | null
          updated_at?: string | null
          user_id: string
          vibe: string
        }
        Update: {
          city?: string
          companion?: string
          created_at?: string | null
          duration_days?: number
          id?: string
          plan_name?: string
          start_date?: string | null
          updated_at?: string | null
          user_id?: string
          vibe?: string
        }
        Relationships: []
      }
      tripadvisor_reviews: {
        Row: {
          created_at: string
          id: string
          place_id: string
          place_name: string
          review_id: number
          review_star: number
          review_text: string
          reviewer_name: string | null
          traveler_type: string
        }
        Insert: {
          created_at?: string
          id?: string
          place_id: string
          place_name: string
          review_id: number
          review_star: number
          review_text: string
          reviewer_name?: string | null
          traveler_type: string
        }
        Update: {
          created_at?: string
          id?: string
          place_id?: string
          place_name?: string
          review_id?: number
          review_star?: number
          review_text?: string
          reviewer_name?: string | null
          traveler_type?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
