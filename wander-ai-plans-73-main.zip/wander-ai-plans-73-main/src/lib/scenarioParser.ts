interface ScenarioData {
  id: string;
  scenario_name: string;
  city: string;
  companions: string;
  vibe: string;
  duration_days: number;
  total_spots: number;
  total_cost_usd: number;
  cost_per_day: number;
  day1_morning_place: string | null;
  day1_morning_category: string | null;
  day1_morning_cost: number | null;
  day1_lunch_place: string | null;
  day1_lunch_category: string | null;
  day1_lunch_cost: number | null;
  day1_evening_place: string | null;
  day1_evening_category: string | null;
  day1_evening_cost: number | null;
  day2_morning_place: string | null;
  day2_morning_category: string | null;
  day2_morning_cost: number | null;
  day2_lunch_place: string | null;
  day2_lunch_category: string | null;
  day2_lunch_cost: number | null;
  day2_evening_place: string | null;
  day2_evening_category: string | null;
  day2_evening_cost: number | null;
  day3_morning_place: string | null;
  day3_morning_category: string | null;
  day3_morning_cost: number | null;
  day3_lunch_place: string | null;
  day3_lunch_category: string | null;
  day3_lunch_cost: number | null;
  day3_evening_place: string | null;
  day3_evening_category: string | null;
  day3_evening_cost: number | null;
  day4_morning_place: string | null;
  day4_morning_category: string | null;
  day4_morning_cost: number | null;
  day4_lunch_place: string | null;
  day4_lunch_category: string | null;
  day4_lunch_cost: number | null;
  day4_evening_place: string | null;
  day4_evening_category: string | null;
  day4_evening_cost: number | null;
}

const parseCSVLine = (line: string): string[] => {
  const result: string[] = [];
  let current = '';
  let inQuotes = false;
  
  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    
    if (char === '"') {
      inQuotes = !inQuotes;
    } else if (char === ',' && !inQuotes) {
      result.push(current.trim());
      current = '';
    } else {
      current += char;
    }
  }
  
  result.push(current.trim());
  return result;
};

export const fetchScenarioFromCSV = async (
  city: string,
  companion: string,
  vibe: string,
  duration: number
): Promise<ScenarioData | null> => {
  try {
    const response = await fetch('/scenario/ScenarioML.csv');
    const text = await response.text();
    const lines = text.split('\n').filter(line => line.trim());
    
    if (lines.length < 2) {
      throw new Error('CSV file is empty or invalid');
    }
    
    const headers = parseCSVLine(lines[0]);
    
    // Find matching scenario
    for (let i = 1; i < lines.length; i++) {
      const values = parseCSVLine(lines[i]);
      const row: Record<string, string> = {};
      
      headers.forEach((header, index) => {
        row[header] = values[index] || '';
      });
      
      // Match criteria
      if (
        row.City === city &&
        row.Companions === companion &&
        row.Vibe === vibe &&
        parseInt(row.Duration_Days) === duration
      ) {
        // Convert CSV row to ScenarioData format
        return {
          id: row.Scenario_ID,
          scenario_name: row.Scenario_ID,
          city: row.City,
          companions: row.Companions,
          vibe: row.Vibe,
          duration_days: parseInt(row.Duration_Days),
          total_spots: parseInt(row.Total_Spots),
          total_cost_usd: parseFloat(row.Total_Cost_USD),
          cost_per_day: parseFloat(row.Cost_Per_Day),
          day1_morning_place: row.Day1_Morning_Place || null,
          day1_morning_category: row.Day1_Morning_Category || null,
          day1_morning_cost: row.Day1_Morning_Cost ? parseFloat(row.Day1_Morning_Cost) : null,
          day1_lunch_place: row.Day1_Lunch_Place || null,
          day1_lunch_category: row.Day1_Lunch_Category || null,
          day1_lunch_cost: row.Day1_Lunch_Cost ? parseFloat(row.Day1_Lunch_Cost) : null,
          day1_evening_place: row.Day1_Evening_Place || null,
          day1_evening_category: row.Day1_Evening_Category || null,
          day1_evening_cost: row.Day1_Evening_Cost ? parseFloat(row.Day1_Evening_Cost) : null,
          day2_morning_place: row.Day2_Morning_Place || null,
          day2_morning_category: row.Day2_Morning_Category || null,
          day2_morning_cost: row.Day2_Morning_Cost ? parseFloat(row.Day2_Morning_Cost) : null,
          day2_lunch_place: row.Day2_Lunch_Place || null,
          day2_lunch_category: row.Day2_Lunch_Category || null,
          day2_lunch_cost: row.Day2_Lunch_Cost ? parseFloat(row.Day2_Lunch_Cost) : null,
          day2_evening_place: row.Day2_Evening_Place || null,
          day2_evening_category: row.Day2_Evening_Category || null,
          day2_evening_cost: row.Day2_Evening_Cost ? parseFloat(row.Day2_Evening_Cost) : null,
          day3_morning_place: row.Day3_Morning_Place || null,
          day3_morning_category: row.Day3_Morning_Category || null,
          day3_morning_cost: row.Day3_Morning_Cost ? parseFloat(row.Day3_Morning_Cost) : null,
          day3_lunch_place: row.Day3_Lunch_Place || null,
          day3_lunch_category: row.Day3_Lunch_Category || null,
          day3_lunch_cost: row.Day3_Lunch_Cost ? parseFloat(row.Day3_Lunch_Cost) : null,
          day3_evening_place: row.Day3_Evening_Place || null,
          day3_evening_category: row.Day3_Evening_Category || null,
          day3_evening_cost: row.Day3_Evening_Cost ? parseFloat(row.Day3_Evening_Cost) : null,
          day4_morning_place: row.Day4_Morning_Place || null,
          day4_morning_category: row.Day4_Morning_Category || null,
          day4_morning_cost: row.Day4_Morning_Cost ? parseFloat(row.Day4_Morning_Cost) : null,
          day4_lunch_place: row.Day4_Lunch_Place || null,
          day4_lunch_category: row.Day4_Lunch_Category || null,
          day4_lunch_cost: row.Day4_Lunch_Cost ? parseFloat(row.Day4_Lunch_Cost) : null,
          day4_evening_place: row.Day4_Evening_Place || null,
          day4_evening_category: row.Day4_Evening_Category || null,
          day4_evening_cost: row.Day4_Evening_Cost ? parseFloat(row.Day4_Evening_Cost) : null,
        };
      }
    }
    
    return null;
  } catch (error) {
    console.error('Error fetching scenario from CSV:', error);
    throw error;
  }
};
