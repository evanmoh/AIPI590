import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { MapPin, Compass, Star, Users } from "lucide-react";
import { Link } from "react-router-dom";
import { Navbar } from "@/components/Navbar";
import durhamHero from "@/assets/durham-hero.jpg";
import nycHero from "@/assets/nyc-hero.jpg";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative h-[600px] overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-primary to-primary/80 opacity-90" />
        <div className="absolute inset-0 bg-[url('/grid.svg')] opacity-10" />
        <div className="container mx-auto px-4 h-full flex items-center relative z-10">
          <div className="max-w-2xl text-white">
            <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
              Plan Your Perfect Trip with AI
            </h1>
            <p className="text-xl mb-8 text-white/90">
              Discover personalized travel recommendations for Durham and New York City. 
              Let our AI help you create the perfect itinerary based on your preferences.
            </p>
            <div className="flex gap-4">
              <Link to="/plan">
                <Button size="lg" className="bg-accent hover:bg-accent/90 text-white">
                  <Compass className="mr-2 h-5 w-5" />
                  Plan Your Trip
                </Button>
              </Link>
              <Link to="/places">
                <Button size="lg" variant="outline" className="bg-white/10 border-white text-white hover:bg-white/20">
                  Explore Places
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Cities Section */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4">Discover Amazing Destinations</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Choose from two incredible cities, each offering unique experiences and unforgettable memories
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto">
            <Card className="overflow-hidden hover:shadow-2xl transition-shadow duration-300">
              <div className="h-64 overflow-hidden">
                <img 
                  src={durhamHero} 
                  alt="Durham, North Carolina" 
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                />
              </div>
              <CardContent className="p-6">
                <div className="flex items-center gap-2 mb-3">
                  <MapPin className="h-5 w-5 text-primary" />
                  <h3 className="text-2xl font-bold">Durham, NC</h3>
                </div>
                <p className="text-muted-foreground mb-4">
                  Explore Duke University, beautiful gardens, historic sites, and a vibrant cultural scene
                </p>
                <Link to="/places?city=Durham">
                  <Button className="w-full">Explore Durham</Button>
                </Link>
              </CardContent>
            </Card>

            <Card className="overflow-hidden hover:shadow-2xl transition-shadow duration-300">
              <div className="h-64 overflow-hidden">
                <img 
                  src={nycHero} 
                  alt="New York City" 
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                />
              </div>
              <CardContent className="p-6">
                <div className="flex items-center gap-2 mb-3">
                  <MapPin className="h-5 w-5 text-primary" />
                  <h3 className="text-2xl font-bold">New York City</h3>
                </div>
                <p className="text-muted-foreground mb-4">
                  Experience world-class museums, iconic landmarks, Central Park, and the vibrant energy of NYC
                </p>
                <Link to="/places?city=New York">
                  <Button className="w-full">Explore NYC</Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4">How WanderWell Works</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Our AI-powered platform makes trip planning simple and personalized
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <Card className="text-center p-6 hover:shadow-lg transition-shadow">
              <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-3">Choose Your Style</h3>
              <p className="text-muted-foreground">
                Select your travel companion, preferred vibe, and trip duration
              </p>
            </Card>

            <Card className="text-center p-6 hover:shadow-lg transition-shadow">
              <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Compass className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-3">Get AI Recommendations</h3>
              <p className="text-muted-foreground">
                Receive personalized itineraries with 3 places per day
              </p>
            </Card>

            <Card className="text-center p-6 hover:shadow-lg transition-shadow">
              <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Star className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-3">Rate & Save</h3>
              <p className="text-muted-foreground">
                Rate places you visit and save your favorite plans
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-primary to-accent text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-4">Ready to Start Your Adventure?</h2>
          <p className="text-xl mb-8 text-white/90 max-w-2xl mx-auto">
            Join WanderWell today and discover your perfect travel experience
          </p>
          <Link to="/plan">
            <Button size="lg" className="bg-white text-primary hover:bg-white/90">
              Plan Your Trip Now
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 border-t">
        <div className="container mx-auto px-4 text-center text-muted-foreground">
          <p>© 2025 WanderWell. Your AI travel companion.</p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
