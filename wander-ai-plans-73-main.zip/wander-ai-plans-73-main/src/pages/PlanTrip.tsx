import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Navbar } from "@/components/Navbar";
import { AuthGuard } from "@/components/AuthGuard";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Compass, MapPin, Users, Sparkles, Calendar } from "lucide-react";

const PlanTrip = () => {
  const navigate = useNavigate();
  const [city, setCity] = useState("");
  const [companion, setCompanion] = useState("");
  const [vibe, setVibe] = useState("");
  const [duration, setDuration] = useState("");

  const handleSubmit = () => {
    if (!city || !companion || !vibe || !duration) {
      return;
    }
    
    navigate(`/recommendations?city=${city}&companion=${companion}&vibe=${vibe}&duration=${duration}`);
  };

  const isFormComplete = city && companion && vibe && duration;

  return (
    <AuthGuard>
      <div className="min-h-screen bg-background">
        <Navbar />
        
        <div className="container mx-auto px-4 py-12">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-8">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
                <Compass className="h-8 w-8 text-primary" />
              </div>
              <h1 className="text-4xl font-bold mb-3">Plan Your Perfect Trip</h1>
              <p className="text-lg text-muted-foreground">
                Tell us about your travel preferences and we'll create a personalized itinerary
              </p>
            </div>

            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle>Trip Preferences</CardTitle>
                <CardDescription>
                  Select your preferences below to get AI-powered recommendations
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* City Selection */}
                <div className="space-y-3">
                  <Label className="flex items-center gap-2 text-base font-semibold">
                    <MapPin className="h-5 w-5 text-primary" />
                    Which city would you like to visit?
                  </Label>
                  <RadioGroup value={city} onValueChange={setCity}>
                    <div className="grid grid-cols-2 gap-4">
                      <label
                        htmlFor="durham"
                        className={`relative flex flex-col items-center gap-2 rounded-lg border-2 p-4 cursor-pointer transition-all ${
                          city === "Durham"
                            ? "border-primary bg-primary/5"
                            : "border-border hover:border-primary/50"
                        }`}
                      >
                        <RadioGroupItem value="Durham" id="durham" className="sr-only" />
                        <span className="text-lg font-medium">Durham, NC</span>
                        <span className="text-sm text-muted-foreground text-center">
                          Historic charm & university culture
                        </span>
                      </label>
                      
                      <label
                        htmlFor="newyork"
                        className={`relative flex flex-col items-center gap-2 rounded-lg border-2 p-4 cursor-pointer transition-all ${
                          city === "New York"
                            ? "border-primary bg-primary/5"
                            : "border-border hover:border-primary/50"
                        }`}
                      >
                        <RadioGroupItem value="New York" id="newyork" className="sr-only" />
                        <span className="text-lg font-medium">New York City</span>
                        <span className="text-sm text-muted-foreground text-center">
                          Iconic landmarks & vibrant energy
                        </span>
                      </label>
                    </div>
                  </RadioGroup>
                </div>

                {/* Companion Selection */}
                <div className="space-y-3">
                  <Label className="flex items-center gap-2 text-base font-semibold">
                    <Users className="h-5 w-5 text-primary" />
                    Who are you traveling with?
                  </Label>
                  <Select value={companion} onValueChange={setCompanion}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select companion" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Solo">Solo - Exploring on my own</SelectItem>
                      <SelectItem value="Couples">Couples - Romantic getaway</SelectItem>
                      <SelectItem value="Friends">Friends - Group adventure</SelectItem>
                      <SelectItem value="Family">Family - All ages welcome</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Vibe Selection */}
                <div className="space-y-3">
                  <Label className="flex items-center gap-2 text-base font-semibold">
                    <Sparkles className="h-5 w-5 text-primary" />
                    What's your preferred vibe?
                  </Label>
                  <RadioGroup value={vibe} onValueChange={setVibe}>
                    <div className="grid grid-cols-2 gap-3">
                      {[
                        { value: "Cultural", desc: "Museums & history" },
                        { value: "Mixed", desc: "Variety of activities" },
                        { value: "Adventure", desc: "Exciting experiences" },
                        { value: "Chill", desc: "Relaxed & peaceful" },
                      ].map((option) => (
                        <label
                          key={option.value}
                          htmlFor={option.value.toLowerCase()}
                          className={`relative flex items-center gap-3 rounded-lg border-2 p-3 cursor-pointer transition-all ${
                            vibe === option.value
                              ? "border-primary bg-primary/5"
                              : "border-border hover:border-primary/50"
                          }`}
                        >
                          <RadioGroupItem
                            value={option.value}
                            id={option.value.toLowerCase()}
                            className="shrink-0"
                          />
                          <div>
                            <span className="font-medium">{option.value}</span>
                            <p className="text-xs text-muted-foreground">{option.desc}</p>
                          </div>
                        </label>
                      ))}
                    </div>
                  </RadioGroup>
                </div>

                {/* Duration Selection */}
                <div className="space-y-3">
                  <Label className="flex items-center gap-2 text-base font-semibold">
                    <Calendar className="h-5 w-5 text-primary" />
                    How many days?
                  </Label>
                  <RadioGroup value={duration} onValueChange={setDuration}>
                    <div className="grid grid-cols-4 gap-3">
                      {["1", "2", "3", "4"].map((days) => (
                        <label
                          key={days}
                          htmlFor={`days-${days}`}
                          className={`relative flex flex-col items-center gap-1 rounded-lg border-2 p-4 cursor-pointer transition-all ${
                            duration === days
                              ? "border-primary bg-primary/5"
                              : "border-border hover:border-primary/50"
                          }`}
                        >
                          <RadioGroupItem value={days} id={`days-${days}`} className="sr-only" />
                          <span className="text-2xl font-bold">{days}</span>
                          <span className="text-xs text-muted-foreground">
                            {days === "1" ? "day" : "days"}
                          </span>
                        </label>
                      ))}
                    </div>
                  </RadioGroup>
                </div>

                <Button
                  onClick={handleSubmit}
                  disabled={!isFormComplete}
                  className="w-full h-12 text-lg"
                  size="lg"
                >
                  Get My Recommendations
                  <Sparkles className="ml-2 h-5 w-5" />
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AuthGuard>
  );
};

export default PlanTrip;
