import { useState, useEffect } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { Navbar } from "@/components/Navbar";
import { AuthGuard } from "@/components/AuthGuard";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Calendar as CalendarIcon, MapPin, Clock, DollarSign, Save, GripVertical, Star, ExternalLink, Sunrise, Sun, Moon, MessageSquare, ChevronLeft, ChevronRight, X, Plus, Trash2 } from "lucide-react";
import { format } from "date-fns";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { fetchScenarioFromCSV } from "@/lib/scenarioParser";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  DndContext,
  closestCenter,
  closestCorners,
  KeyboardSensor,
  PointerSensor,
  TouchSensor,
  MouseSensor,
  useSensor,
  useSensors,
  DragEndEvent,
  useDraggable,
  useDroppable,
} from "@dnd-kit/core";
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";

interface PlaceItem {
  id: string;
  place: string;
  category: string;
  cost: number;
  timeSlot: 'morning' | 'lunch' | 'afternoon' | 'evening' | 'night';
  dayNumber: number;
  image_url?: string;
}

interface TimeSlot {
  place: string | null;
  category: string | null;
  cost: number | null;
}

interface DayItinerary {
  morning: TimeSlot;
  lunch: TimeSlot;
  evening: TimeSlot;
}

interface PlaceDetail {
  id: string;
  place_id: string;
  city: string;
  name: string;
  category: string;
  duration_hours: number;
  avg_cost_usd: number;
  overall_rating: number;
  url: string;
  key_tip: string;
  image_url: string;
  morning_fit: boolean;
  lunch_fit: boolean;
  evening_fit: boolean;
}

// Sortable Place Card Component
const SortablePlaceCard = ({ place, timeLabel, onPlaceClick, onRemove, onTimeSlotChange }: { 
  place: PlaceItem; 
  timeLabel: string; 
  onPlaceClick: (placeName: string) => void; 
  onRemove?: () => void;
  onTimeSlotChange?: (placeId: string, newTimeSlot: PlaceItem['timeSlot']) => void;
}) => {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: place.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  const getTimeDisplay = (slot: string) => {
    const times = { 
      morning: '9:00 AM', 
      lunch: '12:00 PM', 
      afternoon: '3:00 PM',
      evening: '6:00 PM',
      night: '9:00 PM'
    };
    return times[slot as keyof typeof times] || '';
  };

  return (
    <Card ref={setNodeRef} style={style} className="hover:shadow-md transition-shadow touch-none">
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-3 cursor-grab active:cursor-grabbing touch-none" {...attributes} {...listeners}>
          <div className="flex items-start gap-2 flex-1">
            <div className="mt-0.5">
              <GripVertical className="h-4 w-4 text-muted-foreground" />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                {onTimeSlotChange ? (
                  <Select 
                    value={place.timeSlot} 
                    onValueChange={(value) => onTimeSlotChange(place.id, value as PlaceItem['timeSlot'])}
                  >
                    <SelectTrigger 
                      className="w-28 h-6 text-xs"
                      onPointerDown={(e) => e.stopPropagation()}
                      onClick={(e) => e.stopPropagation()}
                    >
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="z-50 bg-popover">
                      <SelectItem value="morning">Morning</SelectItem>
                      <SelectItem value="lunch">Lunch</SelectItem>
                      <SelectItem value="afternoon">Afternoon</SelectItem>
                      <SelectItem value="evening">Evening</SelectItem>
                      <SelectItem value="night">Night</SelectItem>
                    </SelectContent>
                  </Select>
                ) : (
                  <span className="text-xs text-muted-foreground">{timeLabel}</span>
                )}
              </div>
              <h3 
                className="text-base font-bold mb-1 hover:text-primary transition-colors cursor-pointer"
                onClick={(e) => {
                  e.stopPropagation();
                  onPlaceClick(place.place);
                }}
                onPointerDown={(e) => e.stopPropagation()}
              >
                {place.place}
              </h3>
              <Badge variant="secondary" className="text-xs">{place.category}</Badge>
              
              <div className="flex gap-3 text-xs text-muted-foreground mt-2">
                <div className="flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  {getTimeDisplay(place.timeSlot)}
                </div>
                <div className="flex items-center gap-1">
                  <DollarSign className="h-3 w-3" />
                  {place.cost === 0 ? "Free" : `$${place.cost}`}
                </div>
              </div>
            </div>
          </div>
          {place.image_url && (
            <div className="flex-shrink-0">
              <img 
                src={place.image_url} 
                alt={place.place}
                className="w-16 h-16 object-cover rounded-lg"
                onPointerDown={(e) => e.stopPropagation()}
              />
            </div>
          )}
          {onRemove && (
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7 text-muted-foreground hover:text-destructive"
              onClick={(e) => {
                e.stopPropagation();
                onRemove();
              }}
              onPointerDown={(e) => e.stopPropagation()}
            >
              <X className="h-3 w-3" />
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
};


// Unused Place Card Component for Right Pane
const UnusedPlaceCard = ({ place }: { place: PlaceItem }) => {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    isDragging,
  } = useDraggable({ id: place.id });

  const style = {
    transform: transform ? `translate3d(${transform.x}px, ${transform.y}px, 0)` : undefined,
    opacity: isDragging ? 0.5 : 1,
  };

  return (
    <Card
      ref={setNodeRef}
      style={style}
      className="cursor-grab active:cursor-grabbing hover:shadow-md transition-shadow touch-none"
      {...attributes}
      {...listeners}
    >
      <CardContent className="p-3">
        <div className="flex gap-2">
          {place.image_url && (
            <img
              src={place.image_url}
              alt={place.place}
              className="w-12 h-12 object-cover rounded"
            />
          )}
          <div className="flex-1 min-w-0">
            <p className="font-medium text-sm truncate">{place.place}</p>
            <p className="text-xs text-muted-foreground truncate">{place.category}</p>
            <p className="text-xs text-muted-foreground">${place.cost}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

// Droppable Day Component
const DroppableDay = ({ dayNumber, children }: { dayNumber: number; children: React.ReactNode }) => {
  const { setNodeRef, isOver } = useDroppable({
    id: `day-droppable-${dayNumber}`,
  });

  return (
    <div 
      ref={setNodeRef} 
      className={`transition-all duration-200 rounded-lg p-4 ${isOver ? 'bg-primary/5 ring-2 ring-primary/30 ring-offset-4' : ''}`}
    >
      {children}
    </div>
  );
};

// Sortable Day Card Component
const SortableDayCard = ({ 
  day, 
  dayPlaces, 
  dayDate,
  onPlaceClick, 
  onRemovePlace, 
  onTimeSlotChange,
  onDeleteDay,
  onDateChange
}: { 
  day: number;
  dayPlaces: PlaceItem[];
  dayDate: Date | undefined;
  onPlaceClick: (placeName: string) => void;
  onRemovePlace: (placeId: string) => void;
  onTimeSlotChange: (placeId: string, newTimeSlot: PlaceItem['timeSlot']) => void;
  onDeleteDay: (day: number) => void;
  onDateChange: (day: number, date: Date | undefined) => void;
}) => {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: `day-${day}` });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  const timeLabels = {
    morning: 'Morning',
    lunch: 'Lunch',
    afternoon: 'Afternoon',
    evening: 'Evening',
    night: 'Night'
  };

  return (
    <Card ref={setNodeRef} style={style} className="overflow-hidden border-2">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3 flex-wrap">
            <div 
              className="cursor-grab active:cursor-grabbing p-1 hover:bg-muted rounded touch-none"
              {...attributes}
              {...listeners}
            >
              <GripVertical className="h-5 w-5 text-muted-foreground" />
            </div>
            <CalendarIcon className="h-5 w-5 text-primary" />
            <h2 className="text-2xl font-bold">Day {day}</h2>
            
            {/* Date Picker */}
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "h-9 text-sm font-normal",
                    !dayDate && "text-muted-foreground"
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {dayDate ? format(dayDate, "MMM dd, yyyy") : "Set date"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={dayDate}
                  onSelect={(date) => onDateChange(day, date)}
                  initialFocus
                  className={cn("p-3 pointer-events-auto")}
                />
              </PopoverContent>
            </Popover>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 text-destructive hover:text-destructive hover:bg-destructive/10"
            onClick={() => onDeleteDay(day)}
            title={`Delete Day ${day}`}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>

        <DroppableDay dayNumber={day}>
          <div className="space-y-3 min-h-[120px]">
            {dayPlaces.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-8">
                No places added for this day yet. Drag places from the side panel
                to add them.
              </p>
            ) : (
              dayPlaces.map((place) => (
                <SortablePlaceCard
                  key={place.id}
                  place={place}
                  timeLabel={timeLabels[place.timeSlot]}
                  onPlaceClick={onPlaceClick}
                  onRemove={() => onRemovePlace(place.id)}
                  onTimeSlotChange={onTimeSlotChange}
                />
              ))
            )}
          </div>
        </DroppableDay>
      </CardContent>
    </Card>
  );
};

interface Scenario {
  id: string;
  scenario_name: string;
  city: string;
  companions: string;
  vibe: string;
  duration_days: number;
  total_spots: number;
  total_cost_usd: number;
  cost_per_day: number;
  day1_morning_place: string | null;
  day1_morning_category: string | null;
  day1_morning_cost: number | null;
  day1_lunch_place: string | null;
  day1_lunch_category: string | null;
  day1_lunch_cost: number | null;
  day1_evening_place: string | null;
  day1_evening_category: string | null;
  day1_evening_cost: number | null;
  day2_morning_place: string | null;
  day2_morning_category: string | null;
  day2_morning_cost: number | null;
  day2_lunch_place: string | null;
  day2_lunch_category: string | null;
  day2_lunch_cost: number | null;
  day2_evening_place: string | null;
  day2_evening_category: string | null;
  day2_evening_cost: number | null;
  day3_morning_place: string | null;
  day3_morning_category: string | null;
  day3_morning_cost: number | null;
  day3_lunch_place: string | null;
  day3_lunch_category: string | null;
  day3_lunch_cost: number | null;
  day3_evening_place: string | null;
  day3_evening_category: string | null;
  day3_evening_cost: number | null;
  day4_morning_place: string | null;
  day4_morning_category: string | null;
  day4_morning_cost: number | null;
  day4_lunch_place: string | null;
  day4_lunch_category: string | null;
  day4_lunch_cost: number | null;
  day4_evening_place: string | null;
  day4_evening_category: string | null;
  day4_evening_cost: number | null;
}

const Recommendations = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [scenario, setScenario] = useState<Scenario | null>(null);
  const [planName, setPlanName] = useState("");
  const [saving, setSaving] = useState(false);
  const [places, setPlaces] = useState<PlaceItem[]>([]);
  const [selectedPlaceDetail, setSelectedPlaceDetail] = useState<PlaceDetail | null>(null);
  const [showPlaceDetail, setShowPlaceDetail] = useState(false);
  const [userReviews, setUserReviews] = useState<any[]>([]);
  const [tripadvisorReviews, setTripadvisorReviews] = useState<any[]>([]);
  const [selectedCompanionFilter, setSelectedCompanionFilter] = useState("all");
  const [allCityPlaces, setAllCityPlaces] = useState<PlaceItem[]>([]);
  const [isRightPaneOpen, setIsRightPaneOpen] = useState(true);
  const [dayToDelete, setDayToDelete] = useState<number | null>(null);
  const [initialPlaces, setInitialPlaces] = useState<PlaceItem[]>([]);
  const [initialDates, setInitialDates] = useState<Record<number, Date | undefined>>({});
  const [originalPlanId, setOriginalPlanId] = useState<string | null>(null);
  const [showResetDialog, setShowResetDialog] = useState(false);
  const [dayDates, setDayDates] = useState<Record<number, Date | undefined>>({});

  const city = searchParams.get("city");
  const companion = searchParams.get("companion");
  const vibe = searchParams.get("vibe");
  const duration = parseInt(searchParams.get("duration") || "1");
  const [totalDays, setTotalDays] = useState(duration);
  const planId = searchParams.get("planId");

  const sensors = useSensors(
    useSensor(MouseSensor, {
      activationConstraint: {
        distance: 8,
      },
    }),
    useSensor(TouchSensor, {
      activationConstraint: {
        delay: 200,
        tolerance: 8,
      },
    }),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  useEffect(() => {
    if (!city || !companion || !vibe || !duration) {
      navigate("/plan");
      return;
    }
    // Initialize originalPlanId when component mounts
    if (planId && !originalPlanId) {
      setOriginalPlanId(planId);
    }
    fetchRecommendations();
    fetchAllCityPlaces();
  }, [city, companion, vibe, duration, planId]);

  const fetchAllCityPlaces = async () => {
    if (!city) return;
    
    try {
      const { data, error } = await supabase
        .from("places")
        .select("*")
        .eq("city", city);
      
      if (error) throw error;
      
      const cityPlaces: PlaceItem[] = (data || []).map((p, idx) => ({
        id: `unused-${p.id}`,
        place: p.name,
        category: p.category,
        cost: p.avg_cost_usd,
        timeSlot: 'morning',
        dayNumber: 0,
        image_url: p.image_url || undefined,
      }));
      
      setAllCityPlaces(cityPlaces);
    } catch (error) {
      console.error("Error fetching city places:", error);
    }
  };

  const fetchPlaceImages = async (places: PlaceItem[]): Promise<PlaceItem[]> => {
    const placeNames = places.map(p => p.place);
    
    if (placeNames.length === 0) return places;
    
    try {
      const { data, error } = await supabase
        .from("places")
        .select("name, image_url")
        .in("name", placeNames);
      
      if (error) throw error;
      
      const imageMap = new Map(data?.map(p => [p.name, p.image_url]) || []);
      
      return places.map(place => ({
        ...place,
        image_url: imageMap.get(place.place) || undefined
      }));
    } catch (error) {
      console.error("Error fetching place images:", error);
      return places;
    }
  };

  const convertScenarioToPlaces = (scenario: Scenario): PlaceItem[] => {
    const places: PlaceItem[] = [];
    // Keep original 3 time slots for initial generation from CSV
    const timeSlots: Array<'morning' | 'lunch' | 'evening'> = ['morning', 'lunch', 'evening'];
    
    for (let day = 1; day <= duration; day++) {
      timeSlots.forEach((slot) => {
        const prefix = `day${day}_${slot}_` as const;
        const placeName = scenario[`${prefix}place` as keyof Scenario] as string | null;
        const category = scenario[`${prefix}category` as keyof Scenario] as string | null;
        const cost = scenario[`${prefix}cost` as keyof Scenario] as number | null;
        
        if (placeName) {
          places.push({
            id: `${day}-${slot}`,
            place: placeName,
            category: category || '',
            cost: cost || 0,
            timeSlot: slot,
            dayNumber: day,
          });
        }
      });
    }
    
    return places;
  };

  const fetchRecommendations = async () => {
    setLoading(true);
    try {
      if (planId) {
        // Load saved plan with custom places
        const { data: planData, error: planError } = await supabase
          .from("saved_plans")
          .select("*")
          .eq("id", planId)
          .single();

        if (planError) throw planError;

        const { data: placesData, error: placesError } = await supabase
          .from("plan_places")
          .select("*")
          .eq("plan_id", planId)
          .order("day_number", { ascending: true })
          .order("order_in_day", { ascending: true });

        if (placesError) throw placesError;

        if (placesData && placesData.length > 0) {
          // Use saved custom places
          const loadedPlaces: PlaceItem[] = placesData.map((p) => ({
            id: `${p.day_number}-${p.time_slot}`,
            place: p.place_name,
            category: p.place_category,
            cost: p.place_cost,
            timeSlot: p.time_slot as 'morning' | 'lunch' | 'afternoon' | 'evening' | 'night',
            dayNumber: p.day_number,
          }));
          const placesWithImages = await fetchPlaceImages(loadedPlaces);
          setPlaces(placesWithImages);
          setInitialPlaces(placesWithImages); // Store initial plan for loaded plans too
          // Update totalDays based on loaded places
          const maxDay = Math.max(...loadedPlaces.map(p => p.dayNumber));
          setTotalDays(maxDay);
          setPlanName(planData.plan_name);
          
          // Restore dates from start_date
          if (planData.start_date) {
            const startDate = new Date(planData.start_date);
            const restoredDates: Record<number, Date> = {};
            for (let day = 1; day <= maxDay; day++) {
              const date = new Date(startDate);
              date.setDate(startDate.getDate() + (day - 1));
              restoredDates[day] = date;
            }
            setDayDates(restoredDates);
            setInitialDates(restoredDates); // Store initial dates for reset
          }
          
          setOriginalPlanId(planId); // Track the original plan ID for reset
          setLoading(false);
          return;
        }
      }

      // Fetch the first matching scenario from CSV file
      const data = await fetchScenarioFromCSV(city, companion, vibe, duration);

      if (!data) {
        throw new Error('No matching scenario found in CSV');
      }
      
      setScenario(data);
      const convertedPlaces = convertScenarioToPlaces(data);
      const placesWithImages = await fetchPlaceImages(convertedPlaces);
      setPlaces(placesWithImages);
      setInitialPlaces(placesWithImages); // Store initial plan
    } catch (error: any) {
      toast({
        title: "Error",
        description: "Failed to load recommendations",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;

    if (!over) return;

    const activeId = active.id as string;
    const overId = over.id as string;

    // Check if dragging a day card
    if (activeId.startsWith('day-') && overId.startsWith('day-')) {
      const activeDayNum = parseInt(activeId.replace('day-', ''));
      const overDayNum = parseInt(overId.replace('day-', ''));
      
      if (activeDayNum === overDayNum) return;
      
      // Reorder days
      const dayNumbers = Array.from({ length: totalDays }, (_, i) => i + 1);
      const oldIndex = dayNumbers.indexOf(activeDayNum);
      const newIndex = dayNumbers.indexOf(overDayNum);
      const reorderedDays = arrayMove(dayNumbers, oldIndex, newIndex);
      
      // Create a mapping from old day number to new day number
      const dayMapping = new Map<number, number>();
      reorderedDays.forEach((oldDay, index) => {
        dayMapping.set(oldDay, index + 1);
      });
      
      // Update all places with new day numbers
      setPlaces(items => 
        items.map(item => ({
          ...item,
          dayNumber: dayMapping.get(item.dayNumber) || item.dayNumber
        }))
      );
      
      // Update dates to match reordered days and recalculate sequentially
      setDayDates(prev => {
        const newDates: Record<number, Date | undefined> = {};
        
        // First, map the old dates to new positions
        reorderedDays.forEach((oldDay, index) => {
          if (prev[oldDay]) {
            newDates[index + 1] = prev[oldDay];
          }
        });
        
        // Find the first day with a date to use as anchor
        const firstDateDay = Object.keys(newDates)
          .map(k => parseInt(k))
          .sort((a, b) => a - b)
          .find(d => newDates[d]);
        
        // If we have at least one date, recalculate all dates sequentially from the anchor
        if (firstDateDay && newDates[firstDateDay]) {
          const anchorDate = newDates[firstDateDay]!;
          
          // Fill all days based on the anchor
          for (let d = 1; d <= totalDays; d++) {
            const daysFromAnchor = d - firstDateDay;
            const calculatedDate = new Date(anchorDate);
            calculatedDate.setDate(anchorDate.getDate() + daysFromAnchor);
            newDates[d] = calculatedDate;
          }
        }
        
        return newDates;
      });
      
      return;
    }

    // Helper function to sort places by day and time slot
    const sortPlacesByTimeSlot = (items: PlaceItem[]): PlaceItem[] => {
      const timeSlotOrder: PlaceItem['timeSlot'][] = ['morning', 'lunch', 'afternoon', 'evening', 'night'];
      
      // Group by day
      const byDay: Record<number, PlaceItem[]> = {};
      items.forEach(item => {
        if (!byDay[item.dayNumber]) byDay[item.dayNumber] = [];
        byDay[item.dayNumber].push(item);
      });
      
      // Sort each day by time slot
      Object.keys(byDay).forEach(dayKey => {
        const dayNum = parseInt(dayKey);
        byDay[dayNum].sort((a, b) => {
          return timeSlotOrder.indexOf(a.timeSlot) - timeSlotOrder.indexOf(b.timeSlot);
        });
      });
      
      // Flatten back and reassign IDs
      return Object.values(byDay).flat().map((item, index) => ({
        ...item,
        id: item.id.startsWith('unused-') ? item.id : `${item.dayNumber}-${index}`,
      }));
    };

    // Check if dragging from unused places
    if (activeId.startsWith('unused-')) {
      const unusedPlace = allCityPlaces.find(p => p.id === activeId);
      if (!unusedPlace) return;

      // Check if dropping on an empty day droppable zone
      if (overId.startsWith('day-droppable-')) {
        const dayNumber = parseInt(overId.replace('day-droppable-', ''));
        setPlaces((items) => {
          const newPlace: PlaceItem = {
            ...unusedPlace,
            id: `${dayNumber}-${Date.now()}`,
            dayNumber: dayNumber,
            timeSlot: 'morning', // Default to morning for empty days
          };
          const updatedItems = [...items, newPlace];
          return sortPlacesByTimeSlot(updatedItems);
        });
        return;
      }

      // Dropping on an existing place
      setPlaces((items) => {
        const overIndex = items.findIndex((item) => item.id === overId);
        if (overIndex === -1) return items;

        const overPlace = items[overIndex];
        
        // Inherit time slot from the place at insertion point
        const priorPlace = items[overIndex];
        const newPlace: PlaceItem = {
          ...unusedPlace,
          id: `${overPlace.dayNumber}-${Date.now()}`,
          dayNumber: overPlace.dayNumber,
          timeSlot: priorPlace.timeSlot,
        };

        // Insert after the over item
        const newItems = [...items];
        newItems.splice(overIndex + 1, 0, newPlace);
        
        // Sort by time slot to ensure chronological order
        return sortPlacesByTimeSlot(newItems);
      });
      return;
    }

    // Normal reordering within plan
    if (activeId === overId) return;

    setPlaces((items) => {
      const oldIndex = items.findIndex((item) => item.id === activeId);
      const newIndex = items.findIndex((item) => item.id === overId);
      
      if (oldIndex === -1 || newIndex === -1) return items;
      
      const movedItem = items[oldIndex];
      const targetItem = items[newIndex];
      
      // Check if moving within the same day
      if (movedItem.dayNumber === targetItem.dayNumber) {
        // Reorder and auto-sort time slots
        const reorderedItems = arrayMove(items, oldIndex, newIndex);
        
        // Sort time slots within each day
        const timeSlotOrder: PlaceItem['timeSlot'][] = ['morning', 'lunch', 'afternoon', 'evening', 'night'];
        
        // Group by day
        const byDay: Record<number, PlaceItem[]> = {};
        reorderedItems.forEach(item => {
          if (!byDay[item.dayNumber]) byDay[item.dayNumber] = [];
          byDay[item.dayNumber].push(item);
        });
        
        // Sort time slots for each day based on position
        Object.keys(byDay).forEach(dayKey => {
          const dayNum = parseInt(dayKey);
          const dayItems = byDay[dayNum];
          
          // Assign time slots based on position
          dayItems.forEach((item, idx) => {
            const slotIndex = Math.min(idx, timeSlotOrder.length - 1);
            item.timeSlot = timeSlotOrder[slotIndex];
          });
        });
        
        // Flatten back to array
        const result = Object.values(byDay).flat();
        
        return result.map((item, index) => ({
          ...item,
          id: `${item.dayNumber}-${index}`,
        }));
      } else {
        // Moving to a different day - keep original time slot
        const reorderedItems = arrayMove(items, oldIndex, newIndex);
        return reorderedItems.map((item, index) => ({
          ...item,
          id: `${item.dayNumber}-${index}`,
        }));
      }
    });
  };

  const handleRemovePlace = (placeId: string) => {
    // Simply remove the place without changing time slots of remaining places
    setPlaces((items) => items.filter((item) => item.id !== placeId));
  };

  const handleTimeSlotChange = (placeId: string, newTimeSlot: PlaceItem['timeSlot']) => {
    setPlaces((items) => {
      const timeSlotOrder: PlaceItem['timeSlot'][] = ['morning', 'lunch', 'afternoon', 'evening', 'night'];
      const getTimeSlotIndex = (slot: PlaceItem['timeSlot']) => timeSlotOrder.indexOf(slot);
      
      // Find the place being changed and its position
      const changedIndex = items.findIndex(item => item.id === placeId);
      if (changedIndex === -1) return items;
      
      const changedPlace = items[changedIndex];
      const changedDayNumber = changedPlace.dayNumber;
      const newTimeSlotIndex = getTimeSlotIndex(newTimeSlot);
      
      // Update the changed place and adjust neighboring places
      return items.map((item, index) => {
        // Update the changed place
        if (item.id === placeId) {
          return { ...item, timeSlot: newTimeSlot };
        }
        
        // Only check places in the same day
        if (item.dayNumber !== changedDayNumber) {
          return item;
        }
        
        const currentTimeSlotIndex = getTimeSlotIndex(item.timeSlot);
        
        // For places BEFORE the changed place
        if (index < changedIndex) {
          // If their time slot is AFTER the new time slot, adjust it down
          if (currentTimeSlotIndex > newTimeSlotIndex) {
            return { ...item, timeSlot: newTimeSlot };
          }
        }
        
        // For places AFTER the changed place
        if (index > changedIndex) {
          // If their time slot is BEFORE the new time slot, adjust it up
          if (currentTimeSlotIndex < newTimeSlotIndex) {
            return { ...item, timeSlot: newTimeSlot };
          }
        }
        
        return item;
      });
    });
  };

  const handleAddDay = (afterDay: number) => {
    setPlaces((items) => {
      // Shift all days after the insertion point
      const updatedItems = items.map(item => 
        item.dayNumber > afterDay 
          ? { ...item, dayNumber: item.dayNumber + 1 }
          : item
      );
      return updatedItems;
    });
    
    // Update dates - shift up all dates after the insertion point and recalculate
    setDayDates(prev => {
      const newDates: Record<number, Date | undefined> = {};
      const newTotalDays = totalDays + 1;
      
      // First, shift existing dates
      Object.keys(prev).forEach(key => {
        const day = parseInt(key);
        if (day <= afterDay) {
          newDates[day] = prev[day];
        } else {
          newDates[day + 1] = prev[day];
        }
      });
      
      // Auto-fill the new day's date intelligently
      const newDayNumber = afterDay + 1;
      
      // Try to use the previous day's date + 1
      if (prev[afterDay]) {
        const newDate = new Date(prev[afterDay]!);
        newDate.setDate(newDate.getDate() + 1);
        newDates[newDayNumber] = newDate;
        
        // Recalculate all dates after the new day to maintain sequential order
        for (let d = newDayNumber + 1; d <= newTotalDays; d++) {
          const prevDayDate = newDates[d - 1];
          if (prevDayDate) {
            const nextDate = new Date(prevDayDate);
            nextDate.setDate(prevDayDate.getDate() + 1);
            newDates[d] = nextDate;
          }
        }
      }
      // If no previous date, try to use the next day's date - 1
      else if (newDates[newDayNumber + 1]) {
        const newDate = new Date(newDates[newDayNumber + 1]!);
        newDate.setDate(newDate.getDate() - 1);
        newDates[newDayNumber] = newDate;
        
        // Backfill any missing dates before this point
        for (let d = newDayNumber - 1; d >= 1; d--) {
          if (!newDates[d]) {
            const nextDayDate = newDates[d + 1];
            if (nextDayDate) {
              const backfillDate = new Date(nextDayDate);
              backfillDate.setDate(nextDayDate.getDate() - 1);
              newDates[d] = backfillDate;
            }
          } else {
            break; // Stop when we hit an existing date
          }
        }
      }
      
      return newDates;
    });
    
    setTotalDays(prev => prev + 1);
    toast({
      title: "Day added",
      description: `Day ${afterDay + 1} has been added to your itinerary`,
    });
  };

  const handleResetPlan = async () => {
    setShowResetDialog(false);
    
    // If we have an original plan ID, reload from database
    if (originalPlanId) {
      setLoading(true);
      try {
        const { data: planData, error: planError } = await supabase
          .from("saved_plans")
          .select("*")
          .eq("id", originalPlanId)
          .single();

        if (planError) throw planError;

        const { data: placesData, error: placesError } = await supabase
          .from("plan_places")
          .select("*")
          .eq("plan_id", originalPlanId)
          .order("day_number", { ascending: true })
          .order("order_in_day", { ascending: true });

        if (placesError) throw placesError;

        if (placesData && placesData.length > 0) {
          const loadedPlaces: PlaceItem[] = placesData.map((p) => ({
            id: `${p.day_number}-${p.time_slot}`,
            place: p.place_name,
            category: p.place_category,
            cost: p.place_cost,
            timeSlot: p.time_slot as 'morning' | 'lunch' | 'afternoon' | 'evening' | 'night',
            dayNumber: p.day_number,
          }));
          const placesWithImages = await fetchPlaceImages(loadedPlaces);
          setPlaces(placesWithImages);
          
          const maxDay = Math.max(...loadedPlaces.map(p => p.dayNumber));
          setTotalDays(maxDay);
          
          // Restore dates from start_date
          const restoredDates: Record<number, Date> = {};
          if (planData.start_date) {
            const startDate = new Date(planData.start_date);
            for (let day = 1; day <= maxDay; day++) {
              const date = new Date(startDate);
              date.setDate(startDate.getDate() + (day - 1));
              restoredDates[day] = date;
            }
          }
          setDayDates(restoredDates);
          
          toast({
            title: "Plan reset",
            description: "Your plan has been reset to the saved version",
          });
        }
      } catch (error: any) {
        toast({
          title: "Error",
          description: error.message,
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    } else {
      // No saved plan, reset to CSV-based initial plan
      setPlaces([...initialPlaces]);
      setTotalDays(duration);
      setDayDates({});
      toast({
        title: "Plan reset",
        description: "Your plan has been reset to the original itinerary",
      });
    }
  };

  const handleDateChange = (day: number, date: Date | undefined) => {
    setDayDates(prev => {
      const newDates = { ...prev, [day]: date };
      
      // If a date was set, auto-fill ALL days relative to this anchor point
      if (date) {
        const daysArray = Array.from({ length: totalDays }, (_, i) => i + 1);
        const currentDayIndex = daysArray.indexOf(day);
        
        // Fill in dates for all days BEFORE this one (counting backwards)
        for (let i = currentDayIndex - 1; i >= 0; i--) {
          const prevDay = daysArray[i];
          const prevDate = new Date(date);
          prevDate.setDate(date.getDate() - (currentDayIndex - i));
          newDates[prevDay] = prevDate;
        }
        
        // Fill in dates for all days AFTER this one
        for (let i = currentDayIndex + 1; i < daysArray.length; i++) {
          const nextDay = daysArray[i];
          const nextDate = new Date(date);
          nextDate.setDate(date.getDate() + (i - currentDayIndex));
          newDates[nextDay] = nextDate;
        }
      }
      
      return newDates;
    });
  };

  const handleDeleteDay = (dayNumber: number) => {
    setPlaces((items) => {
      // Remove all places from the deleted day
      const filteredItems = items.filter(item => item.dayNumber !== dayNumber);
      
      // Renumber remaining days
      const renumberedItems = filteredItems.map(item => 
        item.dayNumber > dayNumber 
          ? { ...item, dayNumber: item.dayNumber - 1 }
          : item
      );
      
      return renumberedItems;
    });
    
    // Update dates - shift down all dates after deleted day and recalculate
    setDayDates(prev => {
      const newDates: Record<number, Date | undefined> = {};
      Object.keys(prev).forEach(key => {
        const day = parseInt(key);
        if (day < dayNumber) {
          newDates[day] = prev[day];
        } else if (day > dayNumber) {
          newDates[day - 1] = prev[day];
        }
      });
      
      // Find the first day with a date to use as anchor for recalculation
      const newTotalDays = totalDays - 1;
      const firstDateDay = Object.keys(newDates)
        .map(k => parseInt(k))
        .sort((a, b) => a - b)
        .find(d => newDates[d]);
      
      // If we have at least one date, recalculate all dates from that anchor
      if (firstDateDay && newDates[firstDateDay]) {
        const anchorDate = newDates[firstDateDay]!;
        
        // Fill all days based on the anchor
        for (let d = 1; d <= newTotalDays; d++) {
          const daysFromAnchor = d - firstDateDay;
          const calculatedDate = new Date(anchorDate);
          calculatedDate.setDate(anchorDate.getDate() + daysFromAnchor);
          newDates[d] = calculatedDate;
        }
      }
      
      return newDates;
    });
    
    setTotalDays(prev => prev - 1);
    setDayToDelete(null);
    toast({
      title: "Day deleted",
      description: `Day ${dayNumber} has been removed from your itinerary`,
    });
  };

  const unusedPlaces = allCityPlaces.filter(
    (cityPlace) => !places.some((p) => p.place === cityPlace.place)
  );

  const handleSavePlan = async (asNewPlan: boolean = false) => {
    if (!planName.trim()) {
      toast({
        title: "Name required",
        description: "Please enter a name for your travel plan",
        variant: "destructive",
      });
      return;
    }

    setSaving(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      let savedPlanId = planId;

      // Get the start date (Day 1 date)
      const startDate = dayDates[1] || null;

      if (!planId || asNewPlan) {
        // Create new plan
        const { data: plan, error: planError } = await supabase
          .from("saved_plans")
          .insert({
            user_id: user.id,
            plan_name: planName,
            city: city!,
            companion: companion!,
            vibe: vibe!,
            duration_days: totalDays,
            start_date: startDate ? startDate.toISOString().split('T')[0] : null,
          })
          .select()
          .single();

        if (planError) throw planError;
        savedPlanId = plan.id;
      } else {
        // Update existing plan name, duration, and start date
        const { error: updateError } = await supabase
          .from("saved_plans")
          .update({ 
            plan_name: planName,
            duration_days: totalDays,
            start_date: startDate ? startDate.toISOString().split('T')[0] : null,
          })
          .eq("id", planId);

        if (updateError) throw updateError;

        // Delete existing plan places to replace with new ones
        await supabase
          .from("plan_places")
          .delete()
          .eq("plan_id", planId);
      }

      // Insert all places
      const planPlaces = places.map((place, index) => ({
        plan_id: savedPlanId,
        place_name: place.place,
        place_category: place.category,
        place_cost: place.cost,
        time_slot: place.timeSlot,
        day_number: place.dayNumber,
        order_in_day: index,
      }));

      const { error: placesError } = await supabase
        .from("plan_places")
        .insert(planPlaces);

      if (placesError) throw placesError;

      toast({
        title: asNewPlan ? "New plan created!" : "Plan saved!",
        description: asNewPlan ? "Your new travel plan has been created successfully" : "Your travel plan has been saved successfully",
      });

      // Update the original plan ID and initial state after save
      if (asNewPlan && savedPlanId) {
        setOriginalPlanId(savedPlanId);
        setInitialPlaces([...places]);
        setInitialDates({ ...dayDates });
      } else if (!planId && savedPlanId) {
        setOriginalPlanId(savedPlanId);
        setInitialPlaces([...places]);
        setInitialDates({ ...dayDates });
      }
      
      // Update URL with planId if it's a new save
      if ((!planId || asNewPlan) && savedPlanId) {
        navigate(`/recommendations?city=${city}&companion=${companion}&vibe=${vibe}&duration=${duration}&planId=${savedPlanId}`, { replace: true });
      }
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  if (loading || places.length === 0) {
    return (
      <AuthGuard>
        <div className="min-h-screen bg-background">
          <Navbar />
          <div className="container mx-auto px-4 py-12 text-center">
            <div className="h-12 w-12 animate-spin rounded-full border-4 border-primary border-t-transparent mx-auto mb-4" />
            <p className="text-lg text-muted-foreground">Generating your perfect itinerary...</p>
          </div>
        </div>
      </AuthGuard>
    );
  }

  // Use totalDays to display all days including newly added empty days
  const daysArray = Array.from({ length: totalDays }, (_, i) => i + 1);
  
  // Group places by day
  const placesByDay: Record<number, PlaceItem[]> = {};
  places.forEach((place) => {
    if (!placesByDay[place.dayNumber]) {
      placesByDay[place.dayNumber] = [];
    }
    placesByDay[place.dayNumber].push(place);
  });

  const getTotalCost = () => {
    return places.reduce((sum, place) => sum + place.cost, 0);
  };

  const getCostPerDay = () => {
    const total = getTotalCost();
    return duration > 0 ? (total / duration).toFixed(2) : '0.00';
  };

  const handlePlaceClick = async (placeName: string) => {
    try {
      const { data, error } = await supabase
        .from("places")
        .select("*")
        .eq("name", placeName)
        .maybeSingle();

      if (error) throw error;
      
      if (data) {
        setSelectedPlaceDetail(data);
        setShowPlaceDetail(true);
        await fetchReviews(data.id);
      } else {
        toast({
          title: "Place not found",
          description: "Could not find details for this place",
          variant: "destructive",
        });
      }
    } catch (error: any) {
      toast({
        title: "Error",
        description: "Failed to load place details",
        variant: "destructive",
      });
    }
  };

  const fetchReviews = async (placeId: string) => {
    try {
      const { data: ratingsData, error: ratingsError } = await supabase
        .from("ratings")
        .select("*")
        .eq("place_id", placeId)
        .order("created_at", { ascending: false });

      if (ratingsError) {
        console.error("Error fetching ratings:", ratingsError);
        setUserReviews([]);
      } else if (ratingsData && ratingsData.length > 0) {
        const userIds = ratingsData.map(r => r.user_id);
        const { data: profilesData, error: profilesError } = await supabase
          .from("profiles")
          .select("id, full_name")
          .in("id", userIds);

        if (profilesError) {
          console.error("Error fetching profiles:", profilesError);
          setUserReviews(ratingsData.map(r => ({ ...r, profiles: null })));
        } else {
          const reviewsWithProfiles = ratingsData.map(rating => {
            const profile = profilesData?.find(p => p.id === rating.user_id);
            return {
              ...rating,
              profiles: profile || null
            };
          });
          setUserReviews(reviewsWithProfiles);
        }
      } else {
        setUserReviews([]);
      }
    } catch (error: any) {
      console.error("Error fetching user reviews:", error);
      setUserReviews([]);
    }

    try {
      const { data: places } = await supabase
        .from("places")
        .select("place_id")
        .eq("id", placeId)
        .maybeSingle();

      if (places?.place_id) {
        const { data: tripadvisorData, error: tripadvisorError } = await supabase
          .from("tripadvisor_reviews")
          .select("*")
          .eq("place_id", places.place_id)
          .order("created_at", { ascending: false });

        if (tripadvisorError) {
          console.error("Error fetching TripAdvisor reviews:", tripadvisorError);
          setTripadvisorReviews([]);
        } else {
          setTripadvisorReviews(tripadvisorData || []);
        }
      }
    } catch (error: any) {
      console.error("Error fetching TripAdvisor reviews:", error);
      setTripadvisorReviews([]);
    }
  };

  const filteredUserReviews = selectedCompanionFilter === "all" 
    ? userReviews 
    : userReviews.filter(r => r.companion === selectedCompanionFilter);

  const filteredTripadvisorReviews = selectedCompanionFilter === "all"
    ? tripadvisorReviews
    : tripadvisorReviews.filter(r => r.traveler_type === selectedCompanionFilter);

  return (
    <AuthGuard>
      <div className="min-h-screen bg-background">
        <Navbar />
        
        <div className="container mx-auto px-4 py-12">
          <DndContext
            sensors={sensors}
            collisionDetection={closestCorners}
            onDragEnd={handleDragEnd}
          >
            <div className="flex gap-6 max-w-7xl mx-auto">
              <div className="flex-1 max-w-4xl">
            <div className="mb-8">
              <h1 className="text-4xl font-bold mb-4">Your Personalized Itinerary</h1>
              <div className="flex flex-wrap gap-2 mb-6">
                <Badge variant="secondary" className="gap-1">
                  <MapPin className="h-3 w-3" />
                  {city}
                </Badge>
                <Badge variant="secondary">{companion}</Badge>
                <Badge variant="secondary">{vibe}</Badge>
                <Badge variant="secondary">{duration} {duration === 1 ? "day" : "days"}</Badge>
              </div>

              {/* Trip Summary */}
              <Card className="mb-6 bg-primary/5">
                <CardContent className="p-6">
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Total Spots</p>
                      <p className="text-2xl font-bold">{places.length}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Total Cost</p>
                      <p className="text-2xl font-bold">${getTotalCost()}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Cost Per Day</p>
                      <p className="text-2xl font-bold">${getCostPerDay()}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div className="mb-6 p-4 bg-muted/50 rounded-lg">
                <p className="text-sm text-muted-foreground">
                  💡 <strong>Tip:</strong> Click "Set date" to schedule days - following days auto-fill. Drag the grip icon to reorder days, drag places to rearrange, or add new places from the side panel.
                </p>
              </div>

              <div className="space-y-3">
                <div className="flex gap-3">
                  <Input
                    placeholder="Name your plan (e.g., Summer NYC Trip)"
                    value={planName}
                    onChange={(e) => setPlanName(e.target.value)}
                    className="flex-1"
                  />
                  {planId ? (
                    <>
                      <Button onClick={() => handleSavePlan(false)} disabled={saving} variant="default">
                        <Save className="mr-2 h-4 w-4" />
                        {saving ? "Saving..." : "Update Plan"}
                      </Button>
                      <Button onClick={() => handleSavePlan(true)} disabled={saving} variant="outline">
                        <Save className="mr-2 h-4 w-4" />
                        Save as New
                      </Button>
                    </>
                  ) : (
                    <Button onClick={() => handleSavePlan(false)} disabled={saving}>
                      <Save className="mr-2 h-4 w-4" />
                      {saving ? "Saving..." : "Save Plan"}
                    </Button>
                  )}
                </div>
                <Button 
                  onClick={() => setShowResetDialog(true)} 
                  variant="outline" 
                  size="sm"
                  className="w-full"
                  disabled={initialPlaces.length === 0}
                >
                  Reset to Original Plan
                </Button>
              </div>
              {planId && (
                <p className="text-sm text-muted-foreground mt-2">
                  Update your existing plan or save as a new copy
                </p>
              )}
              </div>

              <SortableContext
                items={places.map(p => p.id)}
                strategy={verticalListSortingStrategy}
              >
                <SortableContext
                  items={daysArray.map(d => `day-${d}`)}
                  strategy={verticalListSortingStrategy}
                >
                  <div className="space-y-6">
                    {daysArray.map((day) => {
                      const dayPlaces = placesByDay[day] || [];
                      
                      return (
                        <div key={day} className="space-y-4">
                          {/* Add Day Button - Before */}
                          <div className="flex items-center gap-2">
                            <Button
                              variant="outline"
                              size="icon"
                              className="h-8 w-8"
                              onClick={() => handleAddDay(day - 1)}
                              title={`Add day before Day ${day}`}
                            >
                              <Plus className="h-4 w-4" />
                            </Button>
                          </div>
                          
                          <SortableDayCard
                            day={day}
                            dayPlaces={dayPlaces}
                            dayDate={dayDates[day]}
                            onPlaceClick={handlePlaceClick}
                            onRemovePlace={handleRemovePlace}
                            onTimeSlotChange={handleTimeSlotChange}
                            onDeleteDay={setDayToDelete}
                            onDateChange={handleDateChange}
                          />

                          {/* Add Day Button - After (only after last day) */}
                          {day === daysArray[daysArray.length - 1] && (
                            <div className="flex items-center gap-2">
                              <Button
                                variant="outline"
                                size="icon"
                                className="h-8 w-8"
                                onClick={() => handleAddDay(day)}
                                title={`Add day after Day ${day}`}
                              >
                                <Plus className="h-4 w-4" />
                              </Button>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </SortableContext>
              </SortableContext>
            </div>

            {/* Right Pane - Unused Places */}
            <div className={`transition-all duration-300 ${isRightPaneOpen ? 'w-80' : 'w-12'}`}>
              <div className="sticky top-4">
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => setIsRightPaneOpen(!isRightPaneOpen)}
                  className="mb-4"
                >
                  {isRightPaneOpen ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
                </Button>
                
                {isRightPaneOpen && (
                  <Card className="max-h-[calc(100vh-8rem)] overflow-y-auto">
                    <CardContent className="p-4">
                      <h3 className="font-semibold mb-4">Available Places</h3>
                      <div className="space-y-2">
                        {unusedPlaces.map((place) => (
                          <UnusedPlaceCard key={place.id} place={place} />
                        ))}
                        {unusedPlaces.length === 0 && (
                          <p className="text-sm text-muted-foreground text-center py-4">
                            All places from {city} are in your plan
                          </p>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            </div>
          </div>
          </DndContext>
        </div>

        {selectedPlaceDetail && (
          <Dialog open={showPlaceDetail} onOpenChange={setShowPlaceDetail}>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle className="text-2xl">{selectedPlaceDetail.name}</DialogTitle>
                <DialogDescription>
                  <div className="flex items-center gap-2 mt-2">
                    <MapPin className="h-4 w-4" />
                    {selectedPlaceDetail.city}
                  </div>
                </DialogDescription>
              </DialogHeader>

              <div className="space-y-4">
                <div className="h-64 bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center rounded-lg overflow-hidden">
                  {selectedPlaceDetail.image_url ? (
                    <img src={selectedPlaceDetail.image_url} alt={selectedPlaceDetail.name} className="w-full h-full object-cover" />
                  ) : (
                    <MapPin className="h-24 w-24 text-muted-foreground" />
                  )}
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <h3 className="font-semibold">Category</h3>
                    <Badge variant="secondary">{selectedPlaceDetail.category}</Badge>
                  </div>

                  <div className="space-y-2">
                    <h3 className="font-semibold">Duration</h3>
                    <div className="flex items-center gap-1">
                      <Clock className="h-4 w-4 text-muted-foreground" />
                      <span>{selectedPlaceDetail.duration_hours} hours</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h3 className="font-semibold">Average Cost</h3>
                    <div className="flex items-center gap-1">
                      <DollarSign className="h-4 w-4 text-muted-foreground" />
                      <span>{selectedPlaceDetail.avg_cost_usd === 0 ? "Free" : `$${selectedPlaceDetail.avg_cost_usd}`}</span>
                    </div>
                  </div>

                  {selectedPlaceDetail.overall_rating && (
                    <div className="space-y-2">
                      <h3 className="font-semibold">Rating</h3>
                      <div className="flex items-center gap-1">
                        <Star className="h-4 w-4 fill-amber-400 text-amber-400" />
                        <span>{selectedPlaceDetail.overall_rating.toFixed(1)} / 5.0</span>
                      </div>
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <h3 className="font-semibold">Best Time to Visit</h3>
                  <div className="flex gap-2 flex-wrap">
                    {selectedPlaceDetail.morning_fit && (
                      <Badge variant="outline" className="flex items-center gap-1">
                        <Sunrise className="h-3 w-3" />
                        Morning
                      </Badge>
                    )}
                    {selectedPlaceDetail.lunch_fit && (
                      <Badge variant="outline" className="flex items-center gap-1">
                        <Sun className="h-3 w-3" />
                        Afternoon
                      </Badge>
                    )}
                    {selectedPlaceDetail.evening_fit && (
                      <Badge variant="outline" className="flex items-center gap-1">
                        <Moon className="h-3 w-3" />
                        Evening
                      </Badge>
                    )}
                    {!selectedPlaceDetail.morning_fit && !selectedPlaceDetail.lunch_fit && !selectedPlaceDetail.evening_fit && (
                      <span className="text-muted-foreground">Anytime</span>
                    )}
                  </div>
                </div>

                {selectedPlaceDetail.key_tip && (
                  <div className="space-y-2">
                    <h3 className="font-semibold">Travel Tip</h3>
                    <p className="text-muted-foreground">💡 {selectedPlaceDetail.key_tip}</p>
                  </div>
                )}

                {selectedPlaceDetail.url && (
                  <Button variant="outline" className="w-full" asChild>
                    <a href={selectedPlaceDetail.url} target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="h-4 w-4 mr-2" />
                      View on TripAdvisor
                    </a>
                  </Button>
                )}

                <div className="border-t pt-4">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-semibold flex items-center gap-2">
                      <MessageSquare className="h-4 w-4" />
                      Reviews
                    </h3>
                    <Select value={selectedCompanionFilter} onValueChange={setSelectedCompanionFilter}>
                      <SelectTrigger className="w-[180px]">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Companions</SelectItem>
                        <SelectItem value="Solo">Solo</SelectItem>
                        <SelectItem value="Couples">Couples</SelectItem>
                        <SelectItem value="Friends">Friends</SelectItem>
                        <SelectItem value="Family">Family</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Tabs defaultValue="wanderwell" className="w-full">
                    <TabsList className="grid w-full grid-cols-2">
                      <TabsTrigger value="wanderwell">WanderWell Reviews</TabsTrigger>
                      <TabsTrigger value="tripadvisor">TripAdvisor Reviews</TabsTrigger>
                    </TabsList>
                    
                    <TabsContent value="wanderwell" className="space-y-4 max-h-[300px] overflow-y-auto">
                      {filteredUserReviews.length > 0 ? (
                        filteredUserReviews.map((review) => (
                          <div key={review.id} className="border rounded-lg p-4 space-y-2">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <div className="flex">
                                  {[1, 2, 3, 4, 5].map((star) => (
                                    <Star
                                      key={star}
                                      className={`h-4 w-4 ${
                                        star <= review.rating
                                          ? "fill-amber-400 text-amber-400"
                                          : "text-muted-foreground"
                                      }`}
                                    />
                                  ))}
                                </div>
                                <Badge variant="secondary">{review.companion}</Badge>
                              </div>
                              <span className="text-sm text-muted-foreground">
                                {new Date(review.created_at).toLocaleDateString()}
                              </span>
                            </div>
                            {review.review_text && (
                              <p className="text-sm">{review.review_text}</p>
                            )}
                            <p className="text-xs text-muted-foreground">
                              by {review.profiles?.full_name || "Anonymous"}
                            </p>
                          </div>
                        ))
                      ) : (
                        <p className="text-center text-muted-foreground py-8">
                          No reviews yet. Be the first to review!
                        </p>
                      )}
                    </TabsContent>
                    
                    <TabsContent value="tripadvisor" className="space-y-4 max-h-[300px] overflow-y-auto">
                      {filteredTripadvisorReviews.length > 0 ? (
                        filteredTripadvisorReviews.map((review) => (
                          <div key={review.id} className="border rounded-lg p-4 space-y-2">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <div className="flex">
                                  {[1, 2, 3, 4, 5].map((star) => (
                                    <Star
                                      key={star}
                                      className={`h-4 w-4 ${
                                        star <= review.review_star
                                          ? "fill-amber-400 text-amber-400"
                                          : "text-muted-foreground"
                                      }`}
                                    />
                                  ))}
                                </div>
                                <Badge variant="secondary">{review.traveler_type}</Badge>
                              </div>
                              <span className="text-sm text-muted-foreground">
                                by {review.reviewer_name}
                              </span>
                            </div>
                            <p className="text-sm" dangerouslySetInnerHTML={{ __html: review.review_text.replace(/<br\/>/g, ' ') }}></p>
                          </div>
                        ))
                      ) : (
                        <p className="text-center text-muted-foreground py-8">
                          No TripAdvisor reviews available for this companion type
                        </p>
                      )}
                    </TabsContent>
                  </Tabs>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}

        <AlertDialog open={dayToDelete !== null} onOpenChange={(open) => !open && setDayToDelete(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete Day {dayToDelete}?</AlertDialogTitle>
              <AlertDialogDescription>
                This will permanently delete Day {dayToDelete} and all places in it. This action cannot be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction 
                onClick={() => {
                  if (dayToDelete) {
                    handleDeleteDay(dayToDelete);
                    setDayToDelete(null);
                  }
                }}
                className="bg-destructive hover:bg-destructive/90"
              >
                Delete Day
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        {/* Reset Plan Confirmation Dialog */}
        <AlertDialog open={showResetDialog} onOpenChange={setShowResetDialog}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Reset to Original Plan?</AlertDialogTitle>
              <AlertDialogDescription>
                This will discard all your changes and restore the plan to its original generated state. This action cannot be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction 
                onClick={handleResetPlan}
                className="bg-destructive hover:bg-destructive/90"
              >
                Reset Plan
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </AuthGuard>
  );
};

export default Recommendations;
