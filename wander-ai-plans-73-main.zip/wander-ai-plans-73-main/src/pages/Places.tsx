import { useState, useEffect, useMemo } from "react";
import { Navbar } from "@/components/Navbar";
import { supabase } from "@/integrations/supabase/client";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MapPin, Clock, DollarSign, Star, ExternalLink, Sunrise, Sun, Moon, MessageSquare } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useSearchParams } from "react-router-dom";
import { RatingDialog } from "@/components/RatingDialog";

interface Place {
  id: string;
  place_id: string;
  city: string;
  name: string;
  category: string;
  duration_hours: number;
  avg_cost_usd: number;
  overall_rating: number;
  url: string;
  key_tip: string;
  image_url: string;
  morning_fit: boolean;
  lunch_fit: boolean;
  evening_fit: boolean;
}

const Places = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const cityParam = searchParams.get("city");
  const [allPlaces, setAllPlaces] = useState<Place[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedPlace, setSelectedPlace] = useState<Place | null>(null);
  const [showPlaceDetail, setShowPlaceDetail] = useState(false);
  const [expandedCities, setExpandedCities] = useState<Set<string>>(new Set());
  const [showRatingDialog, setShowRatingDialog] = useState(false);
  const [userReviews, setUserReviews] = useState<any[]>([]);
  const [tripadvisorReviews, setTripadvisorReviews] = useState<any[]>([]);
  const [selectedCompanionFilter, setSelectedCompanionFilter] = useState<string>("all");

  useEffect(() => {
    fetchPlaces();
  }, []);

  const fetchPlaces = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from("places")
        .select("*")
        .order("city")
        .order("overall_rating", { ascending: false });

      if (error) throw error;
      setAllPlaces(data || []);
    } catch (error: any) {
      toast({
        title: "Error",
        description: "Failed to load places",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handlePlaceClick = async (place: Place) => {
    setSelectedPlace(place);
    setShowPlaceDetail(true);
    await fetchReviews(place.id);
  };

  const fetchReviews = async (placeId: string) => {
    // Fetch user reviews independently
    try {
      const { data: ratingsData, error: ratingsError } = await supabase
        .from("ratings")
        .select("*")
        .eq("place_id", placeId)
        .order("created_at", { ascending: false });

      if (ratingsError) {
        console.error("Error fetching ratings:", ratingsError);
        setUserReviews([]);
      } else if (ratingsData && ratingsData.length > 0) {
        // Fetch profiles for these ratings
        const userIds = ratingsData.map(r => r.user_id);
        const { data: profilesData, error: profilesError } = await supabase
          .from("profiles")
          .select("id, full_name")
          .in("id", userIds);

        if (profilesError) {
          console.error("Error fetching profiles:", profilesError);
          setUserReviews(ratingsData.map(r => ({ ...r, profiles: null })));
        } else {
          // Merge ratings with profile data
          const reviewsWithProfiles = ratingsData.map(rating => {
            const profile = profilesData?.find(p => p.id === rating.user_id);
            return {
              ...rating,
              profiles: profile || null
            };
          });
          setUserReviews(reviewsWithProfiles);
        }
      } else {
        setUserReviews([]);
      }
    } catch (error: any) {
      console.error("Error fetching user reviews:", error);
      setUserReviews([]);
    }

    // Fetch TripAdvisor reviews independently
    try {
      const currentPlace = allPlaces.find(p => p.id === placeId);
      if (currentPlace) {
        const { data: taReviews, error: taError } = await supabase
          .from("tripadvisor_reviews")
          .select("*")
          .eq("place_id", currentPlace.place_id)
          .order("review_star", { ascending: false });

        if (taError) {
          console.error("Error fetching TripAdvisor reviews:", taError);
          setTripadvisorReviews([]);
        } else {
          setTripadvisorReviews(taReviews || []);
        }
      }
    } catch (error: any) {
      console.error("Error fetching TripAdvisor reviews:", error);
      setTripadvisorReviews([]);
    }
  };

  const filteredUserReviews = selectedCompanionFilter === "all" 
    ? userReviews 
    : userReviews.filter(review => review.companion === selectedCompanionFilter);

  const filteredTripadvisorReviews = selectedCompanionFilter === "all"
    ? tripadvisorReviews
    : tripadvisorReviews.filter(review => review.traveler_type === selectedCompanionFilter);

  const toggleCityExpanded = (city: string) => {
    setExpandedCities((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(city)) {
        newSet.delete(city);
      } else {
        newSet.add(city);
      }
      return newSet;
    });
  };

  const getPlacesByCity = (city: string) => {
    return allPlaces.filter((place) => place.city === city);
  };

  // Memoize shuffled places to prevent re-shuffling on every render
  const shuffledPlacesByCity = useMemo(() => {
    const result: Record<string, Place[]> = {};
    const cities = [...new Set(allPlaces.map(p => p.city))];
    cities.forEach(city => {
      const cityPlaces = allPlaces.filter(place => place.city === city);
      result[city] = [...cityPlaces].sort(() => Math.random() - 0.5);
    });
    return result;
  }, [allPlaces]);

  const getDisplayPlaces = (city: string) => {
    const shuffledPlaces = shuffledPlacesByCity[city] || getPlacesByCity(city);
    if (expandedCities.has(city)) {
      return shuffledPlaces;
    }
    return shuffledPlaces.slice(0, 3);
  };

  // Filter cities based on URL parameter
  let cities = [...new Set(allPlaces.map((p) => p.city))];
  if (cityParam) {
    cities = cities.filter(city => city === cityParam);
  }

  const handleRatePlace = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      toast({
        title: "Login required",
        description: "Please log in to rate places",
      });
      navigate("/auth");
      return;
    }
    setShowRatingDialog(true);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

        <div className="container mx-auto px-4 py-8">
          <div className="mb-8">
            <h1 className="text-4xl font-bold mb-4">Explore Places</h1>
            <p className="text-muted-foreground text-lg">
              Discover amazing destinations in Durham and New York City
            </p>
          </div>

          {loading ? (
            <div className="space-y-8">
              {[1, 2].map((i) => (
                <div key={i} className="animate-pulse">
                  <div className="h-8 bg-muted rounded w-48 mb-4"></div>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {[1, 2, 3].map((j) => (
                      <Card key={j}>
                        <div className="h-48 bg-muted" />
                        <CardHeader>
                          <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
                          <div className="h-3 bg-muted rounded w-1/2"></div>
                        </CardHeader>
                      </Card>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="space-y-12">
              {cities.map((city) => {
                const displayPlaces = getDisplayPlaces(city);
                const totalPlaces = getPlacesByCity(city).length;
                const isExpanded = expandedCities.has(city);

                return (
                  <div key={city}>
                    <div className="flex items-center justify-between mb-6">
                      <h2 className="text-3xl font-bold">{city}</h2>
                      <span className="text-muted-foreground">{totalPlaces} places</span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-4">
                      {displayPlaces.map((place) => (
                        <Card
                          key={place.id}
                          className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer"
                          onClick={() => handlePlaceClick(place)}
                        >
                          <div className="h-48 bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
                            {place.image_url ? (
                              <img src={place.image_url} alt={place.name} className="w-full h-full object-cover" />
                            ) : (
                              <MapPin className="h-16 w-16 text-muted-foreground" />
                            )}
                          </div>
                          <CardHeader>
                            <CardTitle className="text-xl mb-1">{place.name}</CardTitle>
                            <CardDescription className="flex items-center gap-2">
                              <Badge variant="secondary">{place.category}</Badge>
                            </CardDescription>
                          </CardHeader>
                          <CardContent className="space-y-3">
                            <div className="flex items-center justify-between text-sm">
                              <div className="flex items-center gap-1">
                                <Clock className="h-4 w-4 text-muted-foreground" />
                                <span>{place.duration_hours}h</span>
                              </div>
                              <div className="flex items-center gap-1">
                                <DollarSign className="h-4 w-4 text-muted-foreground" />
                                <span>{place.avg_cost_usd === 0 ? "Free" : `$${place.avg_cost_usd}`}</span>
                              </div>
                              {place.overall_rating && (
                                <div className="flex items-center gap-1">
                                  <Star className="h-4 w-4 fill-amber-400 text-amber-400" />
                                  <span>{place.overall_rating.toFixed(1)}</span>
                                </div>
                              )}
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>

                    {totalPlaces > 3 && (
                      <div className="text-center">
                        <Button variant="outline" onClick={() => toggleCityExpanded(city)}>
                          {isExpanded ? `Show Less` : `Explore ${totalPlaces - 3} More ${city} Places`}
                        </Button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {selectedPlace && (
          <Dialog open={showPlaceDetail} onOpenChange={setShowPlaceDetail}>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle className="text-2xl">{selectedPlace.name}</DialogTitle>
                <DialogDescription>
                  <div className="flex items-center gap-2 mt-2">
                    <MapPin className="h-4 w-4" />
                    {selectedPlace.city}
                  </div>
                </DialogDescription>
              </DialogHeader>

              <div className="space-y-4">
                <div className="h-64 bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center rounded-lg overflow-hidden">
                  {selectedPlace.image_url ? (
                    <img src={selectedPlace.image_url} alt={selectedPlace.name} className="w-full h-full object-cover" />
                  ) : (
                    <MapPin className="h-24 w-24 text-muted-foreground" />
                  )}
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <h3 className="font-semibold">Category</h3>
                    <Badge variant="secondary">{selectedPlace.category}</Badge>
                  </div>

                  <div className="space-y-2">
                    <h3 className="font-semibold">Duration</h3>
                    <div className="flex items-center gap-1">
                      <Clock className="h-4 w-4 text-muted-foreground" />
                      <span>{selectedPlace.duration_hours} hours</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h3 className="font-semibold">Average Cost</h3>
                    <div className="flex items-center gap-1">
                      <DollarSign className="h-4 w-4 text-muted-foreground" />
                      <span>{selectedPlace.avg_cost_usd === 0 ? "Free" : `$${selectedPlace.avg_cost_usd}`}</span>
                    </div>
                  </div>

                  {selectedPlace.overall_rating && (
                    <div className="space-y-2">
                      <h3 className="font-semibold">Rating</h3>
                      <div className="flex items-center gap-1">
                        <Star className="h-4 w-4 fill-amber-400 text-amber-400" />
                        <span>{selectedPlace.overall_rating.toFixed(1)} / 5.0</span>
                      </div>
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <h3 className="font-semibold">Best Time to Visit</h3>
                  <div className="flex gap-2 flex-wrap">
                    {selectedPlace.morning_fit && (
                      <Badge variant="outline" className="flex items-center gap-1">
                        <Sunrise className="h-3 w-3" />
                        Morning
                      </Badge>
                    )}
                    {selectedPlace.lunch_fit && (
                      <Badge variant="outline" className="flex items-center gap-1">
                        <Sun className="h-3 w-3" />
                        Afternoon
                      </Badge>
                    )}
                    {selectedPlace.evening_fit && (
                      <Badge variant="outline" className="flex items-center gap-1">
                        <Moon className="h-3 w-3" />
                        Evening
                      </Badge>
                    )}
                    {!selectedPlace.morning_fit && !selectedPlace.lunch_fit && !selectedPlace.evening_fit && (
                      <span className="text-muted-foreground">Anytime</span>
                    )}
                  </div>
                </div>

                {selectedPlace.key_tip && (
                  <div className="space-y-2">
                    <h3 className="font-semibold">Travel Tip</h3>
                    <p className="text-muted-foreground">💡 {selectedPlace.key_tip}</p>
                  </div>
                )}

                <div className="flex gap-2">
                  {selectedPlace.url && (
                    <Button variant="outline" className="flex-1" asChild>
                      <a href={selectedPlace.url} target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="h-4 w-4 mr-2" />
                        View on TripAdvisor
                      </a>
                    </Button>
                  )}
                  <Button onClick={handleRatePlace} className="flex-1">
                    <Star className="h-4 w-4 mr-2" />
                    Rate Place
                  </Button>
                </div>

                <div className="border-t pt-4">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-semibold flex items-center gap-2">
                      <MessageSquare className="h-4 w-4" />
                      Reviews
                    </h3>
                    <Select value={selectedCompanionFilter} onValueChange={setSelectedCompanionFilter}>
                      <SelectTrigger className="w-[180px]">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Companions</SelectItem>
                        <SelectItem value="Solo">Solo</SelectItem>
                        <SelectItem value="Couples">Couples</SelectItem>
                        <SelectItem value="Friends">Friends</SelectItem>
                        <SelectItem value="Family">Family</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Tabs defaultValue="wanderwell" className="w-full">
                    <TabsList className="grid w-full grid-cols-2">
                      <TabsTrigger value="wanderwell">WanderWell Reviews</TabsTrigger>
                      <TabsTrigger value="tripadvisor">TripAdvisor Reviews</TabsTrigger>
                    </TabsList>
                    
                    <TabsContent value="wanderwell" className="space-y-4 max-h-[300px] overflow-y-auto">
                      {filteredUserReviews.length > 0 ? (
                        filteredUserReviews.map((review) => (
                          <div key={review.id} className="border rounded-lg p-4 space-y-2">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <div className="flex">
                                  {[1, 2, 3, 4, 5].map((star) => (
                                    <Star
                                      key={star}
                                      className={`h-4 w-4 ${
                                        star <= review.rating
                                          ? "fill-amber-400 text-amber-400"
                                          : "text-muted-foreground"
                                      }`}
                                    />
                                  ))}
                                </div>
                                <Badge variant="secondary">{review.companion}</Badge>
                              </div>
                              <span className="text-sm text-muted-foreground">
                                {new Date(review.created_at).toLocaleDateString()}
                              </span>
                            </div>
                            {review.review_text && (
                              <p className="text-sm">{review.review_text}</p>
                            )}
                            <p className="text-xs text-muted-foreground">
                              by {review.profiles?.full_name || "Anonymous"}
                            </p>
                          </div>
                        ))
                      ) : (
                        <p className="text-center text-muted-foreground py-8">
                          No reviews yet. Be the first to review!
                        </p>
                      )}
                    </TabsContent>
                    
                    <TabsContent value="tripadvisor" className="space-y-4 max-h-[300px] overflow-y-auto">
                      {filteredTripadvisorReviews.length > 0 ? (
                        filteredTripadvisorReviews.map((review) => (
                          <div key={review.id} className="border rounded-lg p-4 space-y-2">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <div className="flex">
                                  {[1, 2, 3, 4, 5].map((star) => (
                                    <Star
                                      key={star}
                                      className={`h-4 w-4 ${
                                        star <= review.review_star
                                          ? "fill-amber-400 text-amber-400"
                                          : "text-muted-foreground"
                                      }`}
                                    />
                                  ))}
                                </div>
                                <Badge variant="secondary">{review.traveler_type}</Badge>
                              </div>
                              <span className="text-sm text-muted-foreground">
                                by {review.reviewer_name}
                              </span>
                            </div>
                            <p className="text-sm" dangerouslySetInnerHTML={{ __html: review.review_text.replace(/<br\/>/g, ' ') }}></p>
                          </div>
                        ))
                      ) : (
                        <p className="text-center text-muted-foreground py-8">
                          No TripAdvisor reviews available for this companion type
                        </p>
                      )}
                    </TabsContent>
                  </Tabs>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}

        {selectedPlace && (
          <RatingDialog
            place={selectedPlace}
            open={showRatingDialog}
            onOpenChange={setShowRatingDialog}
            onRated={() => {
              if (selectedPlace) {
                fetchReviews(selectedPlace.id);
              }
            }}
          />
        )}
      </div>
    );
  };
  
  export default Places;
