-- Create table for ML recommendation scenarios
CREATE TABLE public.recommendation_scenarios (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  scenario_name text NOT NULL,
  city text NOT NULL,
  companions text NOT NULL,
  vibe text NOT NULL,
  duration_days integer NOT NULL,
  total_spots integer NOT NULL,
  total_cost_usd numeric NOT NULL,
  cost_per_day numeric NOT NULL,
  day1_morning_place text,
  day1_morning_category text,
  day1_morning_cost numeric,
  day1_lunch_place text,
  day1_lunch_category text,
  day1_lunch_cost numeric,
  day1_evening_place text,
  day1_evening_category text,
  day1_evening_cost numeric,
  day2_morning_place text,
  day2_morning_category text,
  day2_morning_cost numeric,
  day2_lunch_place text,
  day2_lunch_category text,
  day2_lunch_cost numeric,
  day2_evening_place text,
  day2_evening_category text,
  day2_evening_cost numeric,
  day3_morning_place text,
  day3_morning_category text,
  day3_morning_cost numeric,
  day3_lunch_place text,
  day3_lunch_category text,
  day3_lunch_cost numeric,
  day3_evening_place text,
  day3_evening_category text,
  day3_evening_cost numeric,
  day4_morning_place text,
  day4_morning_category text,
  day4_morning_cost numeric,
  day4_lunch_place text,
  day4_lunch_category text,
  day4_lunch_cost numeric,
  day4_evening_place text,
  day4_evening_category text,
  day4_evening_cost numeric,
  created_at timestamp with time zone DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.recommendation_scenarios ENABLE ROW LEVEL SECURITY;

-- Allow public read access to scenarios
CREATE POLICY "Scenarios are viewable by everyone" 
ON public.recommendation_scenarios 
FOR SELECT 
USING (true);