-- Drop the unused recommendation_scenarios table
-- The application uses data from CSV file (public/scenario/ScenarioML.csv) instead
DROP TABLE IF EXISTS public.recommendation_scenarios;