-- Update plan_places table to store complete place information
ALTER TABLE plan_places DROP CONSTRAINT IF EXISTS plan_places_place_id_fkey;

ALTER TABLE plan_places 
  DROP COLUMN IF EXISTS place_id,
  ADD COLUMN IF NOT EXISTS place_name TEXT NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS place_category TEXT NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS place_cost NUMERIC NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS time_slot TEXT NOT NULL DEFAULT 'morning';

-- Update the RLS policies to ensure proper access
DROP POLICY IF EXISTS "Users can manage plan places for their plans" ON plan_places;
DROP POLICY IF EXISTS "Users can view plan places for their plans" ON plan_places;

CREATE POLICY "Users can manage plan places for their plans" 
ON plan_places FOR ALL 
USING (
  EXISTS (
    SELECT 1 FROM saved_plans 
    WHERE saved_plans.id = plan_places.plan_id 
    AND saved_plans.user_id = auth.uid()
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM saved_plans 
    WHERE saved_plans.id = plan_places.plan_id 
    AND saved_plans.user_id = auth.uid()
  )
);