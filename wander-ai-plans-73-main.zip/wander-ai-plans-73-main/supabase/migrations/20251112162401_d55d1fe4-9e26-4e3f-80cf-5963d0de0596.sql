-- Create places table
CREATE TABLE public.places (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  place_id TEXT UNIQUE NOT NULL,
  city TEXT NOT NULL CHECK (city IN ('Durham', 'New York')),
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  duration_hours INTEGER NOT NULL,
  avg_cost_usd INTEGER NOT NULL DEFAULT 0,
  morning_fit BOOLEAN NOT NULL DEFAULT false,
  lunch_fit BOOLEAN NOT NULL DEFAULT false,
  evening_fit BOOLEAN NOT NULL DEFAULT false,
  overall_rating DECIMAL(2,1) CHECK (overall_rating >= 0 AND overall_rating <= 5),
  url TEXT,
  key_tip TEXT,
  image_url TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Create user profiles table
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT,
  email TEXT,
  address TEXT,
  bio TEXT,
  avatar_url TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Create user ratings table
CREATE TABLE public.ratings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  place_id UUID NOT NULL REFERENCES public.places(id) ON DELETE CASCADE,
  rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
  review_text TEXT,
  companion TEXT CHECK (companion IN ('Solo', 'Couples', 'Friends', 'Family')),
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(user_id, place_id)
);

-- Create saved plans table
CREATE TABLE public.saved_plans (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  plan_name TEXT NOT NULL,
  city TEXT NOT NULL CHECK (city IN ('Durham', 'New York')),
  companion TEXT NOT NULL CHECK (companion IN ('Solo', 'Couples', 'Friends', 'Family')),
  vibe TEXT NOT NULL CHECK (vibe IN ('Cultural', 'Mixed', 'Adventure', 'Chill')),
  duration_days INTEGER NOT NULL CHECK (duration_days BETWEEN 1 AND 4),
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Create plan places (itinerary) table
CREATE TABLE public.plan_places (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  plan_id UUID NOT NULL REFERENCES public.saved_plans(id) ON DELETE CASCADE,
  place_id UUID NOT NULL REFERENCES public.places(id) ON DELETE CASCADE,
  day_number INTEGER NOT NULL CHECK (day_number >= 1),
  order_in_day INTEGER NOT NULL CHECK (order_in_day >= 1),
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(plan_id, day_number, order_in_day)
);

-- Enable RLS
ALTER TABLE public.places ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ratings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.saved_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.plan_places ENABLE ROW LEVEL SECURITY;

-- Places policies (public read, no write for now)
CREATE POLICY "Places are viewable by everyone"
  ON public.places FOR SELECT
  USING (true);

-- Profiles policies
CREATE POLICY "Profiles are viewable by everyone"
  ON public.profiles FOR SELECT
  USING (true);

CREATE POLICY "Users can update their own profile"
  ON public.profiles FOR UPDATE
  USING (auth.uid() = id);

CREATE POLICY "Users can insert their own profile"
  ON public.profiles FOR INSERT
  WITH CHECK (auth.uid() = id);

-- Ratings policies
CREATE POLICY "Ratings are viewable by everyone"
  ON public.ratings FOR SELECT
  USING (true);

CREATE POLICY "Users can create their own ratings"
  ON public.ratings FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own ratings"
  ON public.ratings FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own ratings"
  ON public.ratings FOR DELETE
  USING (auth.uid() = user_id);

-- Saved plans policies
CREATE POLICY "Users can view their own plans"
  ON public.saved_plans FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own plans"
  ON public.saved_plans FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own plans"
  ON public.saved_plans FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own plans"
  ON public.saved_plans FOR DELETE
  USING (auth.uid() = user_id);

-- Plan places policies
CREATE POLICY "Users can view plan places for their plans"
  ON public.plan_places FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM public.saved_plans
    WHERE saved_plans.id = plan_places.plan_id
    AND saved_plans.user_id = auth.uid()
  ));

CREATE POLICY "Users can manage plan places for their plans"
  ON public.plan_places FOR ALL
  USING (EXISTS (
    SELECT 1 FROM public.saved_plans
    WHERE saved_plans.id = plan_places.plan_id
    AND saved_plans.user_id = auth.uid()
  ));

-- Trigger for updated_at
CREATE OR REPLACE FUNCTION public.handle_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER set_updated_at_profiles
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();

CREATE TRIGGER set_updated_at_ratings
  BEFORE UPDATE ON public.ratings
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();

CREATE TRIGGER set_updated_at_saved_plans
  BEFORE UPDATE ON public.saved_plans
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();

-- Function to create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', '')
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();