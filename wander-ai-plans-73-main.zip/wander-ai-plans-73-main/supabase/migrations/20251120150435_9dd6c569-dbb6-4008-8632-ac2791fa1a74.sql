-- Remove the restrictive duration_days check constraint to allow any number of days
ALTER TABLE public.saved_plans 
DROP CONSTRAINT saved_plans_duration_days_check;

-- Add a more flexible constraint that allows 1 or more days
ALTER TABLE public.saved_plans 
ADD CONSTRAINT saved_plans_duration_days_check CHECK (duration_days >= 1);