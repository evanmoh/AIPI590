-- Create table for TripAdvisor reviews
CREATE TABLE public.tripadvisor_reviews (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  review_id INTEGER NOT NULL UNIQUE,
  place_id TEXT NOT NULL,
  place_name TEXT NOT NULL,
  review_text TEXT NOT NULL,
  review_star INTEGER NOT NULL CHECK (review_star >= 1 AND review_star <= 5),
  traveler_type TEXT NOT NULL CHECK (traveler_type IN ('Solo', 'Couples', 'Friends', 'Family')),
  reviewer_name TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.tripadvisor_reviews ENABLE ROW LEVEL SECURITY;

-- Create policy for public read access (anyone can view TripAdvisor reviews)
CREATE POLICY "TripAdvisor reviews are viewable by everyone" 
ON public.tripadvisor_reviews 
FOR SELECT 
USING (true);

-- Create index for faster lookups by place_id
CREATE INDEX idx_tripadvisor_reviews_place_id ON public.tripadvisor_reviews(place_id);

-- Create index for faster lookups by traveler_type
CREATE INDEX idx_tripadvisor_reviews_traveler_type ON public.tripadvisor_reviews(traveler_type);