-- Remove the check constraint that limits order_in_day values
ALTER TABLE plan_places DROP CONSTRAINT IF EXISTS plan_places_order_in_day_check;