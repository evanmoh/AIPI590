-- Add start_date column to saved_plans table to persist trip start dates
ALTER TABLE public.saved_plans 
ADD COLUMN start_date DATE;